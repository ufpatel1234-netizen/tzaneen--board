export default class Coordinates {
  constructor(public latitude: number, public longitude: number) {}
}
