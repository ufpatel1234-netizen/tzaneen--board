export const Rounding = {
  Nearest: 'nearest',
  Up: 'up',
  None: 'none',
} as const;
